import { toAbsoluteUrl } from './utils.js';
class PosterPreloader {
    constructor() {
        this.cache = new Map();
        this.inflight = new Set();
    }
    /**
     * Build the marker screenshot URL using scene + marker IDs.
     */
    buildMarkerScreenshotUrl(marker) {
        const markerId = marker?.id;
        const sceneId = marker?.scene?.id;
        if (!markerId || !sceneId)
            return undefined;
        // Path-style endpoint; assume same-origin
        const path = `/scene/${sceneId}/scene_marker/${markerId}/screenshot`;
        return toAbsoluteUrl(path);
    }
    /**
     * Prefetch poster images for a list of markers.
     * Limits to maxCount to avoid overloading the network.
     */
    prefetchForMarkers(markers, maxCount = 24) {
        const slice = markers.slice(0, Math.max(0, maxCount));
        for (const marker of slice) {
            const id = marker?.id;
            if (!id)
                continue;
            if (this.cache.has(id) || this.inflight.has(id))
                continue;
            const url = this.buildMarkerScreenshotUrl(marker);
            if (!url)
                continue;
            this.inflight.add(id);
            // Use Image to warm cache; store on load
            const img = new Image();
            img.onload = () => {
                this.cache.set(id, url);
                this.inflight.delete(id);
            };
            img.onerror = () => {
                // Keep silent; just drop inflight and don't cache failures
                this.inflight.delete(id);
            };
            img.src = url;
        }
    }
    /**
     * Get a cached poster URL for a marker, if available.
     */
    getPosterForMarker(marker) {
        const id = marker?.id;
        if (!id)
            return undefined;
        return this.cache.get(id);
    }
}
export const posterPreloader = new PosterPreloader();
//# sourceMappingURL=PosterPreloader.js.map